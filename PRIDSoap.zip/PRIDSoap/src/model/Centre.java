/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;


import java.util.HashMap;
import java.util.Map;
import model.dao.AbstractDAOFactory;
import model.dao.BibliothequeDAO;


public class Centre {



    public Centre() {
    }


    //@WebMethod(operationName="listLivre")
    public Map<String, Integer> getListLivreContains(String s) {
        AbstractDAOFactory factory = AbstractDAOFactory.getFactory();
        BibliothequeDAO bibliothequeDAO = factory.createBibliothequeDAO();
        return bibliothequeDAO.getListLivreContains(s);
    }

    
    public Map<String, String> stringToMap(String titles) {

        titles = titles.substring(1, titles.length() - 1);
        String[] keyValuePairs = titles.split(",");
        Map<String, String> listLivre = new HashMap<>();
        for (String pair : keyValuePairs) {
            String[] entry = pair.split("=");
            listLivre.put(entry[0].trim(), entry[1].trim());
        }
        return listLivre;
    }
}
