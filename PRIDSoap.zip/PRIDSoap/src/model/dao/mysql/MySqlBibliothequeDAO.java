/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import model.dao.BibliothequeDAO;

/*
 * TODO *
 */
public class MySqlBibliothequeDAO implements BibliothequeDAO {

    public MySqlBibliothequeDAO() {

    }

    private static MySqlBibliothequeDAO instance;

//    static {
//        instance = new MySqlBibliothequeDAO();
//    }
    public static BibliothequeDAO getInstance() {
        if (instance == null) {
            instance = new MySqlBibliothequeDAO();
        }
        return instance;
    }



    @Override
    public Map<String, Integer> getListLivreContains(String string) {
        Connection c = null;
        PreparedStatement st = null;
        ResultSet rs = null;

        Map<String, Integer> map = new HashMap<>();

        String sql = "SELECT livre.titre,COUNT(*) as nombre FROM exemplaire as e, livre  WHERE e.disponible=true AND livre.idLivre = e.idDuLivre  AND livre.titre LIKE ? GROUP BY titre";
        // "SELECT livre.titre as Titre ,bibliotheque.idBibliotheque as idB ,bibliotheque.nom  as nomB, exemplaire.idExemplaire as IdE, exemplaire.type as Type  FROM livre JOIN exemplaire ON exemplaire.idDuLivre = livre.idLivre JOIN possede ON possede.idEx = exemplaire.idExemplaire JOIN bibliotheque ON bibliotheque.idBibliotheque = possede.idBi GROUP BY livre.idLivre";
        try {

            c = MySqlDAOFactory.getInstance().getConnection();
            st = c.prepareStatement(sql);
            st.setString(1, "%" + string + "%");
            rs = st.executeQuery();

            while (rs.next()) {

                map.put(rs.getString("titre"), rs.getInt("nombre"));

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (st != null) {
                    st.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (c != null) {
                    c.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return map;
    }

   

}
