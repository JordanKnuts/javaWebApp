-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 05 jan. 2021 à 10:34
-- Version du serveur :  10.4.17-MariaDB
-- Version de PHP : 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `bibliotheque`
--

-- --------------------------------------------------------

--
-- Structure de la table `avis`
--

CREATE TABLE `avis` (
  `idLivre` int(11) DEFAULT NULL,
  `idLecteur` int(11) DEFAULT NULL,
  `note` float NOT NULL,
  `commentaire` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `bibliotheque`
--

CREATE TABLE `bibliotheque` (
  `idBibliotheque` int(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `idManager` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `bibliotheque`
--

INSERT INTO `bibliotheque` (`idBibliotheque`, `nom`, `adresse`, `idManager`) VALUES
(1, 'Evere', 'rue de la bibliotheque', 2),
(3, 'Anderlecht', 'rue de la biblio', 3),
(4, 'Riche-Claire', 'Rue de la richesse blanche', 6);

-- --------------------------------------------------------

--
-- Structure de la table `exemplaire`
--

CREATE TABLE `exemplaire` (
  `idExemplaire` int(255) NOT NULL,
  `idDuLivre` int(255) NOT NULL,
  `type` varchar(1) NOT NULL,
  `disponible` tinyint(255) DEFAULT 1,
  `vérifié` tinyint(255) DEFAULT NULL,
  `rendu` tinyint(255) DEFAULT NULL,
  `chemin` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `exemplaire`
--

INSERT INTO `exemplaire` (`idExemplaire`, `idDuLivre`, `type`, `disponible`, `vérifié`, `rendu`, `chemin`) VALUES
(1, 1, 'N', NULL, NULL, NULL, ''),
(2, 1, 'P', 1, NULL, NULL, ''),
(3, 1, 'P', 1, NULL, NULL, ''),
(4, 2, 'P', 1, 0, 0, ''),
(5, 2, 'P', 1, NULL, NULL, ''),
(6, 2, 'P', 1, NULL, NULL, ''),
(7, 3, 'P', 1, 0, 0, ''),
(11, 3, 'P', 1, NULL, NULL, ''),
(23, 3, 'P', 1, NULL, NULL, ''),
(24, 3, 'P', 1, NULL, NULL, ''),
(25, 4, 'P', 1, NULL, NULL, ''),
(26, 4, 'P', 1, NULL, NULL, ''),
(27, 5, 'P', 1, NULL, NULL, ''),
(28, 5, 'P', 1, NULL, NULL, ''),
(29, 6, 'P', 1, NULL, NULL, ''),
(30, 6, 'P', 1, NULL, NULL, ''),
(31, 6, 'N', 1, NULL, NULL, 'C:\\Users\\jknut\\OneDrive\\Documents\\GitHub\\ProjetPRIDBibliotheque\\com.mycompany_ProjetPRID\\src\\main\\webapp\\drop\\Sans titre.png'),
(32, 7, 'N', 1, NULL, NULL, 'C:\\Users\\jknut\\OneDrive\\Documents\\GitHub\\ProjetPRIDBibliotheque\\com.mycompany_ProjetPRID\\src\\main\\webapp\\drop\\Sans titre.png');

-- --------------------------------------------------------

--
-- Structure de la table `inscription`
--

CREATE TABLE `inscription` (
  `idUser` int(255) NOT NULL,
  `idBibliotheque` int(255) NOT NULL,
  `cotisationPaye` tinyint(255) DEFAULT NULL,
  `datePayement` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `inscription`
--

INSERT INTO `inscription` (`idUser`, `idBibliotheque`, `cotisationPaye`, `datePayement`) VALUES
(22, 3, 1, '2021-01-04'),
(3, 3, 0, '2021-01-04'),
(6, 4, 0, '2021-01-04'),
(2, 1, 0, '2021-01-04'),
(4, 1, 0, '2021-01-04'),
(24, 4, 1, '2021-01-04'),
(5, 1, 0, NULL),
(23, 3, 0, NULL),
(25, 4, 0, '2021-01-04');

-- --------------------------------------------------------

--
-- Structure de la table `livre`
--

CREATE TABLE `livre` (
  `idLivre` int(255) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `auteur` varchar(255) NOT NULL,
  `edition` varchar(255) NOT NULL,
  `nbPage` int(255) NOT NULL,
  `note` float(255,0) DEFAULT NULL,
  `prix` float(255,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `livre`
--

INSERT INTO `livre` (`idLivre`, `titre`, `auteur`, `edition`, `nbPage`, `note`, `prix`) VALUES
(1, 'Harry Potter', 'JK Rowling', 'Gallimard', 450, NULL, 13),
(2, '1984', 'Georges Orwell', 'Gallimard', 500, NULL, 15),
(3, 'Les 4 accords Toltèque', 'Miguel Ruiz', 'Jouvance', 175, NULL, 17),
(4, 'Le miroir de Cassandre', 'Bernard Weber', 'Broché', 400, NULL, 22),
(5, 'Charlie', 'Stephen King', 'lgf', 376, NULL, 17),
(6, 'Les fourmis', 'Bernard Weber', 'De poche', 654, NULL, 13),
(7, 'Misery', 'Stephen King', 'Postal', 654, NULL, 16);

-- --------------------------------------------------------

--
-- Structure de la table `location`
--

CREATE TABLE `location` (
  `idLocation` int(255) NOT NULL,
  `idExemplaire` int(255) NOT NULL,
  `idUser` int(255) NOT NULL,
  `date` date NOT NULL,
  `pageAtteinte` int(255) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `location`
--

INSERT INTO `location` (`idLocation`, `idExemplaire`, `idUser`, `date`, `pageAtteinte`) VALUES
(1, 4, 22, '2021-01-04', 0),
(2, 7, 24, '2021-01-07', 0);

-- --------------------------------------------------------

--
-- Structure de la table `possede`
--

CREATE TABLE `possede` (
  `idExemplaire` int(11) NOT NULL,
  `idBibliotheque` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `possede`
--

INSERT INTO `possede` (`idExemplaire`, `idBibliotheque`) VALUES
(2, 3),
(4, 3),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(6, 4),
(7, 4),
(11, 4),
(23, 4),
(24, 4),
(25, 3),
(26, 3),
(27, 1);

-- --------------------------------------------------------

--
-- Structure de la table `qr`
--

CREATE TABLE `qr` (
  `idQuestion` int(255) NOT NULL,
  `idAuteur` int(255) NOT NULL,
  `idBibliotecaire` int(255) DEFAULT NULL,
  `question` varchar(255) NOT NULL,
  `reponse` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

CREATE TABLE `role` (
  `idRole` int(255) NOT NULL,
  `nomRole` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `role`
--

INSERT INTO `role` (`idRole`, `nomRole`) VALUES
(1, 'manager general'),
(2, 'bibliothecaire manager'),
(3, 'bibliothecaire'),
(4, 'lecteur');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `idUser` int(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `idRole` int(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `amende` float(255,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`idUser`, `nom`, `prenom`, `adresse`, `telephone`, `email`, `idRole`, `login`, `password`, `amende`) VALUES
(1, 'Romano', 'Carmelo', 'Rue de la java', '0455263254', 'managerGeneral@biblio.be', 1, 'managerG', '$2a$10$9CYwqRO7aCsm9ScsvzRLXudw2PEw9L2wBVYcS9hwZcBtwweaKAI7m', NULL),
(2, 'Ali', 'Yussef', 'Rue de barbès', '0486523652', 'managerBiblio@biblio.be', 2, 'managerE', '$2a$10$9CYwqRO7aCsm9ScsvzRLXudw2PEw9L2wBVYcS9hwZcBtwweaKAI7m', NULL),
(3, 'Nbayo', 'Victoire', 'Avenue d\'Ixelles', '0499632566', 'bibliothecaire@biblio.be', 2, 'managerA', '$2a$10$9CYwqRO7aCsm9ScsvzRLXudw2PEw9L2wBVYcS9hwZcBtwweaKAI7m', NULL),
(4, 'Napoli', 'Francesca', 'Rue de la Mbotè', '0466325698', 'lectrice@biblio.be', 4, 'Franci', '$2a$10$9CYwqRO7aCsm9ScsvzRLXudw2PEw9L2wBVYcS9hwZcBtwweaKAI7m', NULL),
(5, 'Hance', 'Fabien', 'Rue du burger', '06666666', 'fabinou@xxx.be', 3, 'bibliothecaireE', '$2a$10$9CYwqRO7aCsm9ScsvzRLXudw2PEw9L2wBVYcS9hwZcBtwweaKAI7m', NULL),
(6, 'Gandouz', 'El Amin', 'Rue du professeur', '045896589', 'aminPro@email.com', 2, 'managerRC', '$2a$10$9CYwqRO7aCsm9ScsvzRLXudw2PEw9L2wBVYcS9hwZcBtwweaKAI7m', NULL),
(22, 'Gandouz', 'Myriam', 'Rue sainte marie', '06547852', 'mymy@biblio.be', 4, 'MyriamG', '$2a$10$9CYwqRO7aCsm9ScsvzRLXudw2PEw9L2wBVYcS9hwZcBtwweaKAI7m', NULL),
(23, 'Jerome', 'Colle', 'Rue mima', '0456965236', 'jerome@hello.be', 3, 'bibliothecaireA', '$2a$10$9CYwqRO7aCsm9ScsvzRLXudw2PEw9L2wBVYcS9hwZcBtwweaKAI7m', NULL),
(24, 'Pichotte', 'Marcus', 'Rue des franÃ§ais', '065254154', 'marcos@locos.fr', 4, 'marcos', '$2a$10$5Az5wS70jnw5fbtHjTTDDu9Phn/NmV/NV2Ef5Xb4P/l1YS1Dd.hdG', NULL),
(25, 'Kara', 'Alex', 'Rue de service', '046985655', 'alex@mail.de', 3, 'bibliothecaireRC', '$2a$10$jIy.KC5OWGTjR1mH.0N7q.a0GnzKGqk0ISBKU0ipKg9z0FTkDyOUq', NULL);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `avis`
--
ALTER TABLE `avis`
  ADD KEY `idLecteur` (`idLecteur`),
  ADD KEY `idLivre` (`idLivre`);

--
-- Index pour la table `bibliotheque`
--
ALTER TABLE `bibliotheque`
  ADD PRIMARY KEY (`idBibliotheque`),
  ADD KEY `idMan` (`idManager`);

--
-- Index pour la table `exemplaire`
--
ALTER TABLE `exemplaire`
  ADD PRIMARY KEY (`idExemplaire`),
  ADD KEY `idLi` (`idDuLivre`);

--
-- Index pour la table `inscription`
--
ALTER TABLE `inscription`
  ADD KEY `idUserInscr` (`idUser`),
  ADD KEY `idBibliot` (`idBibliotheque`);

--
-- Index pour la table `livre`
--
ALTER TABLE `livre`
  ADD PRIMARY KEY (`idLivre`);

--
-- Index pour la table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`idLocation`),
  ADD KEY `idExem` (`idExemplaire`),
  ADD KEY `idUs` (`idUser`);

--
-- Index pour la table `possede`
--
ALTER TABLE `possede`
  ADD KEY `idExemp` (`idExemplaire`),
  ADD KEY `idBibli` (`idBibliotheque`);

--
-- Index pour la table `qr`
--
ALTER TABLE `qr`
  ADD PRIMARY KEY (`idQuestion`),
  ADD KEY `idAuteur` (`idAuteur`),
  ADD KEY `idBibliotecaire` (`idBibliotecaire`);

--
-- Index pour la table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`idRole`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idUser`),
  ADD KEY `idRole` (`idRole`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `bibliotheque`
--
ALTER TABLE `bibliotheque`
  MODIFY `idBibliotheque` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `exemplaire`
--
ALTER TABLE `exemplaire`
  MODIFY `idExemplaire` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT pour la table `livre`
--
ALTER TABLE `livre`
  MODIFY `idLivre` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `location`
--
ALTER TABLE `location`
  MODIFY `idLocation` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `qr`
--
ALTER TABLE `qr`
  MODIFY `idQuestion` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `role`
--
ALTER TABLE `role`
  MODIFY `idRole` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `idUser` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `avis`
--
ALTER TABLE `avis`
  ADD CONSTRAINT `avis_ibfk_1` FOREIGN KEY (`idLecteur`) REFERENCES `user` (`idUser`),
  ADD CONSTRAINT `avis_ibfk_2` FOREIGN KEY (`idLivre`) REFERENCES `livre` (`idLivre`);

--
-- Contraintes pour la table `bibliotheque`
--
ALTER TABLE `bibliotheque`
  ADD CONSTRAINT `idMan` FOREIGN KEY (`idManager`) REFERENCES `user` (`idUser`);

--
-- Contraintes pour la table `exemplaire`
--
ALTER TABLE `exemplaire`
  ADD CONSTRAINT `idLi` FOREIGN KEY (`idDuLivre`) REFERENCES `livre` (`idLivre`);

--
-- Contraintes pour la table `inscription`
--
ALTER TABLE `inscription`
  ADD CONSTRAINT `idBibliot` FOREIGN KEY (`idBibliotheque`) REFERENCES `bibliotheque` (`idBibliotheque`),
  ADD CONSTRAINT `idUserInscr` FOREIGN KEY (`idUser`) REFERENCES `user` (`idUser`);

--
-- Contraintes pour la table `location`
--
ALTER TABLE `location`
  ADD CONSTRAINT `idExem` FOREIGN KEY (`idExemplaire`) REFERENCES `exemplaire` (`idExemplaire`),
  ADD CONSTRAINT `idUs` FOREIGN KEY (`idUser`) REFERENCES `user` (`idUser`);

--
-- Contraintes pour la table `possede`
--
ALTER TABLE `possede`
  ADD CONSTRAINT `idBibli` FOREIGN KEY (`idBibliotheque`) REFERENCES `bibliotheque` (`idBibliotheque`),
  ADD CONSTRAINT `idExemp` FOREIGN KEY (`idExemplaire`) REFERENCES `exemplaire` (`idExemplaire`);

--
-- Contraintes pour la table `qr`
--
ALTER TABLE `qr`
  ADD CONSTRAINT `idAuteur` FOREIGN KEY (`idAuteur`) REFERENCES `user` (`idUser`),
  ADD CONSTRAINT `idBibliotecaire` FOREIGN KEY (`idBibliotecaire`) REFERENCES `user` (`idUser`);

--
-- Contraintes pour la table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `idRole` FOREIGN KEY (`idRole`) REFERENCES `role` (`idRole`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
